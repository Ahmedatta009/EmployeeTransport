Saqin Mars v2 - Android app
Arabic supervisor/driver transport operations app.
Supervisor: supervisor / 1234
Demo driver: ahmed / 1234
Second demo driver: mohamed / 1234

This build stores data locally on the device. Cloud sync/Firebase can be added as a next step for multiple phones.
